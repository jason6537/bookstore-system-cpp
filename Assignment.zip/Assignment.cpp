#include<iostream>
#include<iomanip>
#include<cstdlib>
#include<string>
using namespace std;

//struct declaration
struct greats_book 
{
	string title;
	string author;
	string publisher;
	long long isbn;
	string category;
	int edition;
	double price;
	double review;
	double rating;
}; 

struct mps_book 
{
	string title;
	string author;
	string publisher;
	long long isbn;
	string category;
	int edition;
	double price;
	double review;
	double rating;
}; 

struct sunnys_book 
{
	string title;
	string author;
	string publisher;
	long long isbn;
	string category;
	int edition;
	double price;
	double review;
	double rating;
};

//function prototype
void printGreeting(); //greeting
void bookstoreMenu(); //main menu
void greatBookstoreMenu(); //great's bookstore
void greatsChoice(greats_book book1[]);
void greatsBestSeller(greats_book book1[]);
void greatsBooksMonth(greats_book book1[]);
void mpBookstoreMenu(); //mp's bookstore
void mpsChoice(mps_book book2[]);
void mpsBestSeller(mps_book book2[]);
void mpsBooksMonth(mps_book book2[]);
void sunnyBookstoreMenu();//sunny's bookstore
void sunnysChoice(sunnys_book book3[]);
void sunnysBestSeller(sunnys_book book3[]);
void sunnysBooksMonth(sunnys_book book3[]);
void searchBooks(); //books' details all over the bookstore
void displayBooksTitle(string input);
void displayBooksCategory(string input);
void displayISBN(string input);
void displayBooksPublisher(string input);
void displayBooksAuthor(string input);
void displayBooksEdition(string input);
void displayBooksPrice(double input);
void displayRating(int input);

//create a book instance
greats_book book1[] = {
{"Anna Karenina","Leo Tolstoy","Wordsworth Editions Ltd",9781853262715,"Fiction",1995,66.00},
{"Mrs Dalloway","Virginia Woolf","Harcourt",9780151628629,"Psychological Fiction",1970,74.00},
{"Harry Potter and the Sorcerer's Stone","J.K. Rowling","Scholastic",9780590353427,"Fantasy",1999,59.00},
{"Harry Potter and the Chamber of Secrets","J.K. Rowling","Bloomsbury childrens",9781408855669,"Fantasy",2014,47.00},
{"Harry Potter and the Prisoner of Azkaban","J.K. Rowling","Bloomsbury childrens",9781408855676,"Fantasy",2014,47.00},
{"Harry Potter and the Goblet of Fire","J.K. Rowling","Bloomsbury childrens",9781408855683,"Fantasy",2014,56.00},
{"Harry Potter and the Order of the Phoenix","J.K. Rowling","Bloomsbury childrens",9781408855690,"Fantasy",2014,56.00},
{"Harry Potter and the Half-Blood Prince","J.K. Rowling","Bloomsbury childrens",9781408855706,"Fantasy",2014,56.00},
{"Harry Potter and the Deathly Hallows","J.K. Rowling","Bloomsbury Publishing PLC",9781408865453,"Fantasy",2015,53.00},
{"Harry Potter and the Cursed Child","J.K. Rowling","Arthur A. Levine Books",9781338216677,"Fantasy",2014,147.00},
{"Jurassic Park","Michael Crichton","Alfred A. Knopf",9780091821340,"Sci-Fic",1990,60.00},
{"The Hunger Game","Suzanne Collins","Scholastic Press",9780439023528,"Action",1970,78.00},
{"A Court of Mist and Fury","Sarah J. Maas","Bloomsbury Publishing PLC",9781526617163,"Fiction",2020,56.00},
{"Piranesi","Susanna Clarke","Bloomsbury Publishing PLC",9781526622433,"Magical Realism",2021,56.00},
{"The Shadows Between Us","Tricia Levenseller","Pushkin Children's Books",9781782693727,"Fantasy Fiction",2023,53.00},
{"The Girl He Used To Know","Graves Tracey Garvis","Orion",9781409183693,"Romance",2019,47.00},
{"A Compass to Fulfillment","Kazuo Inamori","McGraw-Hill",9780071615099,"Self-help",1970,126.00},
{"Think Again","Adam Grant","Ebury Publishing",9780753553893,"Self-help",2021,73.00},
{"The God Equation","Michio Kaku","Penguin Books Ltd",9780141995199,"Science",2022,58.00},
{"Maybe You Should Talk to Someone","Lori Gottlieb","Scribe Publications Pty Ltd",9781913348922,"Memoir",2022,63.00},
{"The Great Gatsby","F. Scott Fitzgerald","Penguin Books",9780141182636,"Historical Fiction",2000,39.00},
{"Wuthering Heights","Emily Bront�","White's Books",9780955881855,"Romance",1970,146.00},
{"Nineteen Eighty-Four","Orwell, George","Penguin Books",9780141036144,"Sci-Fic",2008,40.00},
{"Pride and Prejudice","Jane Austen","Wordsworth Editions",9781853260001,"Fiction",1992,50.00},
{"The Catcher In The Rye","Salinger Jd","Little, Brown and Company",9780316769488,"Bildungsroman",1970,45.00},
{"Moby Dick","Herman Melville","Wordsworth Editions Ltd",9781853260087,"Adventure-Fiction",1970,59.00},
{"A Christmas Carol","Charles Dickens","Dover Publications",9780486268651,"Fairy Tale",1991,27.00},
{"Animal Farm","Paperback","Secker and Warburg",9780141036137,"Allegory",1970,40.00},
{"Lord of the Flies","Golding, William","Perigee Books",9780399501487,"Allegory",1959,37.00},
{"The Bell Jar","Sylvia Plath","G. K. Hall & Company",9780783819877,"Autobiography's",1970,181.00}
};

mps_book book2[] = {
{"Harry Potter and the Sorcerer's Stone","J.K. Rowling","Scholastic",9780590353427,"Fantasy",1999,60.00},
{"Harry Potter and the Chamber of Secrets","J.K. Rowling","Bloomsbury childrens",9781408855669,"Fantasy",2014,45.00},
{"Harry Potter and the Prisoner of Azkaban","J.K. Rowling","Bloomsbury childrens",9781408855676,"Fantasy",2014,48.00},
{"Harry Potter and the Goblet of Fire","J.K. Rowling","Bloomsbury childrens",9781408855683,"Fantasy",2014,54.00},
{"Harry Potter and the Order of the Phoenix","J.K. Rowling","Bloomsbury childrens",9781408855690,"Fantasy",2014,53.00},
{"Harry Potter and the Half-Blood Prince","J.K. Rowling","Bloomsbury childrens",9781408855706,"Fantasy",2014,52.00},
{"Harry Potter and the Deathly Hallows","J.K. Rowling","Bloomsbury Publishing PLC",9781408865453,"Fantasy",2015,50.00},
{"Harry Potter and the Cursed Child","J.K. Rowling","Arthur A. Levine Books",9781338216677,"Fantasy",2014,135.00},
{"The Rules Of Thinking","Templar","PEARSON",9781292263809,"Self-Improvement",2019,59.00},
{"WRECK THIS JOURNAL: NOW IN COLOR","Keri Smith","PENGUIN BOOKS",9780143131663,"Self-Improvement",2017,61.00},
{"MINDSET","Dweck Carol","BALLANTINE",9780345472328,"Self-Improvement",2016,65.00},
{"LATERAL THINKING: A TEXTBOOK OF CREATIVITY","Edward De Bono","PENGUIN LIFE",9780241257548,"Self-Improvement",2016,58.00},
{"TEACH YOURSELF TO THINK","Edward De Bono","PENGUIN LIFE",9780241257500,"Self-Improvement",2015,55.00},
{"GE MEI LIA-KOKKO & MAY 6","Eddie See","UPH",9789670659121,"Comics",2016,12.00},
{"GE MEI LIA-KOKKO & MAY 8","Eddie See","UPH",9789670745152,"Comics",2015,12.00},
{"TMHGHOST: THE UNITED KINGDOM","Chan-Ho Kwan","EXACT PUBLISHING SDN BHD",9789673504480,"Comics",2019,15.00},
{"TMHGHOST: KOREA","Hye Ryeon Kim","WORLD OF MYSTERIES",9789673505623,"Comics",2019,15.00},
{"50 FRENCH COFFEE BREAKS","Coffee Break Languages","John Murray Press",9781399802369,"Language",2022,73.00},
{"50 ITALIAN COFFEE BREAKS","Coffee Break Languages","John Murray Press",9781399802390,"Language",2022,73.00},
{"50 SPANISH COFFEE BREAKS","Coffee Break Languages","John Murray Press",9781399802451,"Language",2022,73.00},
{"SHORT STORIES IN JAPANESE","Olly Richards","John Murray Press",9781529377163,"Language",2022,73.00},
{"PRACTICAL ENGLISH MALAY CONVERSATION","Ibrahim Ismail","GOLDEN BOOKS",9789679959642,"Language",2019,15.00},
{"JAP VOCABULARY FOR SPEAKERS","Kartar Diamond","GOLDEN BOOKS",9789679959888,"Language",2019,18.00},
{"METAVERSED: SEE BEYOND THE HYPE","Samantha G. Wolfe","WILEY",9781119888581,"Business & Management",2023,125.00},
{"HOW TO WORK WITHOUT LOSING YOUR MIND","Cate Sevilla","Penguin Books Ltd",9780241988992,"Business & Management",2023,70.00},
{"THE GROWTH DELUSION: THE WEALTH AND WELL","David Pilling","BLOOMSBURY UK",9781408893746,"Business & Management",2019,65.00},
{"THEY ASK, YOU ANSWER","Sheridan","WILEY",9781119610144,"Marketing & Sales",2019,86.00},
{"THE REPUTATION GAME","David Waller","ONEWORLD B",9781786073518,"Marketing & Sales",2018,64.00},
{"THE SALES BIBLE, NEW EDITION: THE ULTIMATE SALES RESOURCE","Jeffrey Gitomer","JOHN WILEY",9781118985816,"Marketing & Sales",2014,72.00},
{"IT'S WHO YOU KNOW : MAKE NETWORKING WORK","Janine Gamer","WILEY",9780730369530,"Marketing & Sales",2019,63.00}
};

sunnys_book book3[]{
{"50 ITALIAN COFFEE BREAKS","Coffee Break Languages","John Murray Press",9781399802390,"Language",2022,70.00},
{"THEY ASK, YOU ANSWER","Sheridan","WILEY",9781119610144,"Marketing & Sales",2019,85.00},
{"THE REPUTATION GAME","David Waller","ONEWORLD B",9781786073518,"Marketing & Sales",2018,60.00},
{"GE MEI LIA-KOKKO & MAY 6","Eddie See","UPH",9789670659121,"Comics",2016,11.00},
{"GE MEI LIA-KOKKO & MAY 8","Eddie See","UPH",9789670745152,"Comics",2015,11.00},
{"APPY PRINCE AND OTHER TALES","Oscar Wilde","Faber",9789394984059,"Classics",2023,50.00},
{"PENANG CHRONICLES 2: PEARL","Rose Gan","Monsoon Books",9781915310002,"Classics",2022,50.00},
{"THE STORY OF MY LIFE","Helen Keller","Dover Publications",9789394984035,"Classics",2022,40.00},
{"Emma","Jane Austen","MIND TO MIND",9789670062440,"Classics",2022,14.00},
{"Dracula","Bram Stroker","MIND TO MIND",9789670062426,"Classics",2022,14.00},
{"THE CALL OF THE WILD & WHITE FANG","Jack London","MIND TO MIND",9789670062419,"Classics",2022,14.00},
{"ALICE'S ADVENTURES IN WONDERLAND","Lewis Carroll","MIND TO MIND",9789670062389,"Classics",2022,13.00},
{"JOURNEY TO THE CENTRE OF THE EARTH","Jules Verne","MIND TO MIND",9789670062471,"Classics",2022,14.00},
{"THE POWER OF CHOWA: FINDING YOUR BALANCE","Akemi Tanaka","HEADLINE",9781472267856,"Classics",2019,80.00},
{"PE - FAR AND NEAR","Pearl S . Buck","POPULAR UK",9789386869661,"Classics",2019,46.00},
{"KING OF PRIDE (KINGS OF SIN BOOK 2)","Ana Huang","Little, Brown Book Group",9780349436340,"Romance",2023,60.00},
{"VIOLETA","Isabel Allende","Bloomsbury Publishing PLC",9781526656919,"Romance",2023,50.00},
{"JUST MY TYPE","Falon Ballard","Penguin Putnam Inc",9780593419939,"Romance",2023,55.00},
{"THE NO-SHOW","Beth O'Leary","Quercus Publishing",9781529409147,"Romance",2023,50.00},
{"SOMEONE ELSE'S SHOES","Jojo Moyes","Penguin Books Ltd",9780241415542,"Romance",2023,95.00},
{"WAHALA","Nikki May","Transworld Publishers Ltd",9781804990872,"Romance",2023,55.00},
{"DO I KNOW YOU?","Emily Wibberley","Random House USA Inc",9780593201954,"Romance",2023,47.00},
{"A DAY OF FALLEN NIGHT","Samantha Shannon","Bloomsbury Publishing PLC",9781526619761,"Sci-Fic",2023,60.00},
{"BOOK OF NIGHT","Holly Black","Cornerstone",9781529102390,"Sci-Fic",2023,50.00},
{"GLOW","Raven Kennedy","Penguin Books Ltd",9781405955065,"Sci-Fic",2023,55.00},
{"A VENOM DARK AND SWEET","Judy I. Lin","Titan Books Ltd",9781803362205,"Sci-Fic",2023,47.00},
{"HOW HIGH WE GO IN THE DARK","Sequoia Nagamatsu","William Morrow",9780063072657,"Sci-Fic",2023,55.00},
{"THE LAST GRADUATE","Naomi Novik","Cornerstone",9781529100907,"Sci-Fic",2022,50.00},
{"FLOCK","Kate Stewart","Pan Macmillan",9781035013487,"Sci-Fic",2022,50.00},
{"PROJECT HAIL MARY","Andy Weir","Cornerstone",9781529157468,"Sci-Fic",2022,58.00},
{"THE LAST GRADUATE","Naomi Novik","Cornerstone",9781529100907,"Sci-Fic",2022,50.00},
{"FLOCK","Kate Stewart","Pan Macmillan",9781035013487,"Sci-Fic",2022,50.00},
{"PROJECT HAIL MARY","Andy Weir","Cornerstone",9781529157468,"Sci-Fic",2022,58.00}
};

int main()
{
	//call the function
	printGreeting();
	bookstoreMenu();

	return 0;
}

//function definition
void printGreeting() //greeting
{
	cout << "Belo! Welcome to Nomi Books Centre!\n";
	cout << endl;
	cout << "We have 3 bookstores in our one-stop centre," << 
		 "feel free to explore \nthe bookstores below " <<
		"and shop online for your favourite books!\n";
	cout << endl;
}

void bookstoreMenu() //main menu
{
	int option = 1;
	do {
		cout << "Select the option below to continue from 1-4\n";
		cout << "1.\tThe Great Bookstore\n";
		cout << "2.\tMP Bookstore\n";
		cout << "3.\tSunny Bookstore\n";
		cout << "4.\tSearch for books\n";
		cout << "5.\tExit\n";
		cout << "Option: ";
		cin >> option;
		system("Cls");

		if (option == 1)
		{
			greatBookstoreMenu();
		}
		else if (option == 2)
		{
			mpBookstoreMenu();
		}
		else if (option == 3)
		{
			sunnyBookstoreMenu();
		}
		else if (option == 4)
		{
			searchBooks();
		}
		else if (option == 5)
		{
			exit(0);
		}
		else
		{
			cout << "Error!! Invalid option!\n";
		}
	} while (option != 5);
}

void greatBookstoreMenu() //great's menu
{
	int option = 1;
	do {
		cout << "Select the option below to continue from 1-4\n";
		cout << "1.\t GREAT'S CHOICE to Read\n";
		cout << "2.\t BEST SELLERS in GREAT'S\n";
		cout << "3.\t BOOKS OF THE MONTH in GREAT'S\n";
		cout << "4.\t Back to Main Menu\n";
		cout << "Option: ";
		cin >> option;
		system("Cls");

		if (option == 1)
		{
			// greatsChoice(greats_book book1[]);
			// global scope book1 variable from int main function to global file scope.
			greatsChoice(book1);
		}
		else if (option == 2)
		{
			greatsBestSeller(book1);
		}
		else if (option == 3)
		{
			greatsBooksMonth(book1);
		}
		else if (option == 4)
		{
			bookstoreMenu();
		}
		else
		{
			cout << "Error!! Invalid option!\n";
		}
	} while (option != 4);
}

void greatsChoice(greats_book book1[]) //great's choice
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 0; i < 10; i++)
		{
			cout << i + 1 << ". " << "Title: " << book1[i].title << endl
				<< "   " << "Author: " << book1[i].author << endl
				<< "   " << "Category: " << book1[i].category << endl
				<< "   " << "Price: RM" << book1[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void greatsBestSeller(greats_book book1[]) //great's best seller
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 10; i < 20; i++)
		{
			cout << i - 9 << ". " << "Title: " << book1[i].title << endl
				<< "   " << "Author: " << book1[i].author << endl
				<< "   " << "Category: " << book1[i].category << endl
				<< "   " << "Price: RM" << book1[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void greatsBooksMonth(greats_book book1[]) //great's books of the month
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 20; i < 30; i++)
		{
			cout << i - 19 << ". " << "Title: " << book1[i].title << endl
				<< "   " << "Author: " << book1[i].author << endl
				<< "   " << "Category: " << book1[i].category << endl
				<< "   " << "Price: RM" << book1[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void mpBookstoreMenu() //mp's menu
{
	int option = 1;
	do {
		cout << "Select the option below to continue :-)\n";
		cout << "1.\t MP'S CHOICE to Read\n";
		cout << "2.\t BEST SELLERS in MP'S\n";
		cout << "3.\t BOOKS OF THE MONTH in MP'S\n";
		cout << "4.\t Back to Main Menu\n";
		cout << "Option: ";
		cin >> option;
		system("Cls");

		if (option == 1)
		{
			mpsChoice(book2);
		}
		else if (option == 2)
		{
			mpsBestSeller(book2);
		}
		else if (option == 3)
		{
			mpsBooksMonth(book2);
		}
		else if (option == 4)
		{
			bookstoreMenu();
		}
		else
		{
			cout << "Error!! Invalid option!\n";
		}
	} while (option != 4);
}

void mpsChoice(mps_book book2[]) //mp's choice
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 0; i < 10; i++)
		{
			cout << i + 1 << ". " << "Title: " << book2[i].title << endl
				<< "   " << "Author: " << book2[i].author << endl
				<< "   " << "Category: " << book2[i].category << endl
				<< "   " << "Price: RM" << book2[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void mpsBestSeller(mps_book book2[]) //mp's best seller
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 10; i < 20; i++)
		{
			cout << i - 9 << ". " << "Title: " << book2[i].title << endl
				<< "   " << "Author: " << book2[i].author << endl
				<< "   " << "Category: " << book2[i].category << endl
				<< "   " << "Price: RM" << book2[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void mpsBooksMonth(mps_book book2[]) //mp's books of the month
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 20; i < 30; i++)
		{
			cout << i - 19 << ". " << "Title: " << book2[i].title << endl
				<< "   " << "Author: " << book2[i].author << endl
				<< "   " << "Category: " << book2[i].category << endl
				<< "   " << "Price: RM" << book2[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void sunnyBookstoreMenu() //sunny menu
{
	int option = 1;
	do {
		cout << "Select the option below to continue :-)\n";
		cout << "1.\t SUNNY'S CHOICE to Read\n";
		cout << "2.\t BEST SELLERS in SUNNY'S\n";
		cout << "3.\t BOOKS OF THE MONTH in SUNNY'S\n";
		cout << "4.\t Back to Main Menu\n";
		cout << "Option: ";
		cin >> option;
		system("Cls");

		if (option == 1)
		{
			sunnysChoice(book3);
		}
		else if (option == 2)
		{
			sunnysBestSeller(book3);
		}
		else if (option == 3)
		{
			sunnysBooksMonth(book3);
		}
		else if (option == 4)
		{
			bookstoreMenu();
		}
		else
		{
			cout << "Error!! Invalid option!\n";
		}
	} while (option != 4);
}

void sunnysChoice(sunnys_book book3[]) //sunny's choice
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 0; i < 10; i++)
		{
			cout << i + 1 << ". " << "Title: " << book3[i].title << endl
				<< "   " << "Author: " << book3[i].author << endl
				<< "   " << "Category: " << book3[i].category << endl
				<< "   " << "Price: RM" << book3[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void sunnysBestSeller(sunnys_book book3[]) //sunny's best seller
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 10; i < 20; i++)
		{
			cout << i - 9 << ". " << "Title: " << book3[i].title << endl
				<< "   " << "Author: " << book3[i].author << endl
				<< "   " << "Category: " << book3[i].category << endl
				<< "   " << "Price: RM" << book3[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void sunnysBooksMonth(sunnys_book book3[]) //sunny's books of the month
{
	int selected_books[10] = {};	//initialize selected_books array to 0
	int num_selected_books = 0;
	int option = 1;

	do {	//print list of the books
		for (int i = 20; i < 30; i++)
		{
			cout << i - 19 << ". " << "Title: " << book3[i].title << endl
				<< "   " << "Author: " << book3[i].author << endl
				<< "   " << "Category: " << book3[i].category << endl
				<< "   " << "Price: RM" << book3[i].price << endl << endl;
		}
		cout << "Select a book to add to your cart (1-" << 10 << "), or enter 0 to exit: ";
		cin >> option;
		system("Cls");

		if (option >= 1 && option <= 10)	// check if the book has already been selected
		{
			if (selected_books[option - 1] == 0)	// add the book to the cart
			{
				selected_books[option - 1] = 1;
				num_selected_books++;
				cout << "Added \"" << book1[option - 1].title << "\" to your cart." << endl;
			}
			else
			{
				cout << "Book \"" << book1[option - 1].title << "\" has already been selected." << endl;
			}
		}
		else if (option != 0)
		{
			cout << "Invalid option. Please enter a number between 1 and " << 10
				<< ", or 0 to back to Great's Bookstore menu." << endl;
		}
	} while (option != 0 && num_selected_books < 10); // exit if all books have been selected or the user enters 0

	cout << "You have selected the following books:" << endl;
	for (int i = 0; i < 10; i++)
	{
		if (selected_books[i] == 1)
		{
			cout << "- " << book1[i].title << endl;
		}
	}
}

void searchBooks() //books' details all over the bookstore
{
	string input;
	cout << "Enter book details such as title, author, publisher, category, edition, ISBN, price in RM,\n";
	cout << "or reviews/ratings of books from 1 to 5:\n";
	getline(cin, input);

	if (!input.empty()) {
		displayBooksTitle(input);
		displayBooksCategory(input);
		displayISBN(input);
		displayBooksPublisher(input);
		displayBooksAuthor(input);
		displayBooksEdition(input);
		displayBooksPrice(stod(input));
		displayRating(stoi(input));
	}
	else {
		cout << "Error! Record Not Found!!" << endl;
	}
	system("Cls");
}

void displayBooksTitle(string input)
{

}

void displayBooksCategory(string input)
{

}

void displayISBN(string input)
{

}

void displayBooksPublisher(string input)
{

}

void displayBooksAuthor(string input)
{

}

void displayBooksEdition(string input)
{

}

void displayBooksPrice(double input)
{

}

void displayRating(int input)
{

}